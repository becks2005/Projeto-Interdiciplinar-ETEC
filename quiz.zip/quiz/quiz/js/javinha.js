function correta()
{
    
    var n1 = document.querySelector("input[name='alternativa1']:checked").value;
    var n2= document.querySelector("input[name='alternativa2']:checked").value;
    var n3 =document.querySelector("input[name='alternativa3']:checked").value;
    var n4 = document.querySelector("input[name='alternativa4']:checked").value;
    var n5 = document.querySelector("input[name='alternativa5']:checked").value;
    var n6 =document.querySelector("input[name='alternativa6']:checked").value;
    var n7 = document.querySelector("input[name='alternativa7']:checked").value;
    var n8 = document.querySelector("input[name='alternativa8']:checked").value;
    var n9 = document.querySelector("input[name='alternativa9']:checked").value;
    var n10 = document.querySelector("input[name='alternativa10']:checked").value;
    var cont1=0
    var cont2=0

    
    if (n1 =="cr")
    {
        document.write(" 1º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 1º - Errada"+"<br>");
        cont2++;


    }
    if (n2=="cr")
    {
        document.write(" 2º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 2º - Errada"+"<br>");
        cont2++;


    }
    if (n3=="cr")
    {
        document.write(" 3º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 3º - Errada"+"<br>");
        cont2++;


    }
    
    if (n4=="cr")
    {
        document.write(" 4º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 4º - Errada"+"<br>");
        cont2++;


    }
    
    if (n5=="cr")
    {
        document.write(" 5º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 5º - Errada"+"<br>");
        cont2++;


    }
    
    if (n6=="cr")
    {
        document.write(" 6º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 6º - Errada"+"<br>");
        cont2++;


    }
    
    if (n7=="cr")
    {
        document.write(" 7º - Certa"+"<br>");
        cont1++;

    }else{


        document.write(" 7º - Errada"+"<br>");
        cont2++;


    }
    
    if (n8=="cr")
    {
        document.write("8º - Certa"+"<br>");
        cont1++;

    }else{


        document.write("8º - Errada"+"<br>");
        cont2++;


    }
    
    if (n9=="cr")
    {
        document.write("9º - Certa"+"<br>");
        cont1++;

    }else{


        document.write("9º - Errada"+"<br>");
        cont2++;



    }
    
    if (n10=="cr")
    {
        document.write("10º - Certa"+"<br>");
        cont1++;

    }else{


        document.write("10º - Errada"+"<br>");
        cont2++;


    }
    document.write("Respostas Corretas: ",cont1, "<br>");
    document.write("Respostas Erradas: ",cont2 );
    

    




}